/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author hi
 */
public class HomePaintingWorkQueue {
    private ArrayList<HomePaintingWorkRequest> homePaintingRequestList;

    public ArrayList<HomePaintingWorkRequest> getHomePaintingRequestList() {
        return homePaintingRequestList;
    }

    public void setHomePaintingRequestList(ArrayList<HomePaintingWorkRequest> homePaintingRequestList) {
        this.homePaintingRequestList = homePaintingRequestList;
    }
    
    
}
