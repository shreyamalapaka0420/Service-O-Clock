/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package WorkQueue;

import java.util.ArrayList;

/**
 *
 * @author hi
 */
public class PestControlWorkQueue {
    private ArrayList<PestControlWorkRequest> pestControlWorkRequestList;

    public ArrayList<PestControlWorkRequest> getPestControlWorkRequestList() {
        return pestControlWorkRequestList;
    }

    public void setPestControlWorkRequestList(ArrayList<PestControlWorkRequest> pestControlWorkRequestList) {
        this.pestControlWorkRequestList = pestControlWorkRequestList;
    }

}
